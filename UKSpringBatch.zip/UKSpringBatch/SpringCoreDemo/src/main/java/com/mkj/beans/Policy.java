package com.mkj.beans;

public class Policy {

	private String policyName;
	private int amount;
	
	public Policy(String policyName, int amount) {
		super();
		this.policyName = policyName;
		this.amount = amount;
	}
	public Policy() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "Policy [policyName=" + policyName + ", amount=" + amount + "]";
	}
	
	
}
