package com.mkj.mains;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.mkj.beans.Accounts;
import com.mkj.config.AccountsConfig;

public class AccountJavaConfigDI {

	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = 
				new AnnotationConfigApplicationContext(AccountsConfig.class);
		Accounts account = (Accounts)context.getBean("createAccount");
		System.out.println(account);
		
		Accounts account2 = (Accounts)context.getBean("createAccountProperty");
		System.out.println(account2);
		
	}
	
	

}
