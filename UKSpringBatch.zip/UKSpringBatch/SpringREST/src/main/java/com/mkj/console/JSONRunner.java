package com.mkj.console;

import java.io.File;
import java.io.IOException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mkj.web.bean.Order;

public class JSONRunner {

	public static void main(String[] args) {
	
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-order-config.xml");
		ObjectMapper json = context.getBean("json",ObjectMapper.class);
		File f = context.getBean("f",File.class);
		
		Order order = null;
		
		try {
			order = json.readValue(f,Order.class);
		} catch (IOException e) {
			System.out.println(e);
		}
		System.out.println(order);
		
	}
}
