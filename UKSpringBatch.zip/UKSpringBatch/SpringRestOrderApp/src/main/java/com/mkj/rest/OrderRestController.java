package com.mkj.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class OrderRestController {

	List<Order> list = new ArrayList<>();

	public OrderRestController() {
		System.out.println("\n ========= OrderRestController Constructor Called ===========\n");
		list.add(new Order(101, "ramesh", "delhi -123", "Dell Laptop", 1000));
		list.add(new Order(102, "suresh", "noida -123", "HP Laptop", 1100));
		list.add(new Order(103, "mahesh", "mumbai -123", "Dell Laptop", 900));

	}

	@RequestMapping("/hello")
	public String doThis() {
		System.out.println("========= hello req Called ===========");
		return "hello";
	}

	@CrossOrigin(origins = "http://localhost:8083")
	@RequestMapping(value = "/order", method = RequestMethod.GET, produces = { "application/json" })
	public Order getOrder() {
		System.out.println(" inside getorder : single order ");
		return new Order(101, "hamid", "Dubai-downtown", "Coffee Mug", 10);
	}

	@CrossOrigin(origins = "http://localhost:8083")
	@RequestMapping(value = "/orders", method = RequestMethod.GET, produces = { "application/json" })
	public List<Order> getOrders() {
		System.out.println(" inside getorder : list ");
		return list;
	}

	@CrossOrigin(origins = "http://localhost:8083")
	@RequestMapping(value = "/order/{orderId}", method = RequestMethod.GET, produces = { "application/json" })
	public Order getOrderByID(@PathVariable int orderId) throws Exception {
		System.out.println(" inside getorder : order for id  " + orderId);
		boolean isFound = false;
		Order temp = null;
		for (Order order : list) {
			if (order.getOrderNumber() == orderId) {
				isFound = true;
				temp = order;
			}
		}

		if (!isFound)
			throw new InvalidOrderIDException(" Order Number " + orderId + " not available in the list");
		else
			return temp;
	}

	@CrossOrigin(origins = "http://localhost:8083")
	@PostMapping("/order")
	public boolean addOrder(@RequestBody Order order) throws Exception {
		System.out.println(" inside order post " + order);
		boolean b = list.add(order);
		return b;
	}

	@CrossOrigin(origins = "http://localhost:8083")
	@GetMapping("/order/{product}")
	public List<Order> addOrder(@PathVariable String product) throws Exception {
		boolean isFound = false;
		List<Order> tempList = new ArrayList<>();

		for (Order order : list) {
			if (order.getProduct().equals(product)) {
				tempList.add(order);
			}
		}

		if (tempList.size() == 0)
			throw new NoOrderException(" Order For " + product + " not available in the list");
		else
			return tempList;
	}

}
