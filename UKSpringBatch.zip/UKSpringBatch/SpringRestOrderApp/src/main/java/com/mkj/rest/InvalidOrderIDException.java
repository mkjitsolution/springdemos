package com.mkj.rest;

public class InvalidOrderIDException extends Exception{

	public InvalidOrderIDException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidOrderIDException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
