package com.mkj.beans.policybeans;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("Policy.properties")
public class MediClaimPolicy implements Policy 
{

	@Value("${medi.policyName}")
	private String policyName;
	private List<String> preHistory;
	@Value("${medi.sumInsured}")
	private int sumInsured;
	@Value("6850")
	private int premiumAmount;
	private boolean isCorporatePolicy;

	public MediClaimPolicy() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public MediClaimPolicy(String policyName,
			List<String> preHistory,
			boolean isCorporatePolicy) {
		super();
		this.policyName = policyName;
		this.preHistory = preHistory;
		this.isCorporatePolicy = isCorporatePolicy;
	}



	public String getPolicyName() {
		return policyName;
	}
	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}
	public List<String> getPreHistory() {
		return preHistory;
	}
	public void setPreHistory(List<String> preHistory) {
		this.preHistory = preHistory;
	}

	public int getSumInsured() {
		return sumInsured;
	}
	public void setSumInsured(int sumInsured) {
		this.sumInsured = sumInsured;
	}

	public int getPremiumAmount() {
		return premiumAmount;
	}
	public void setPremiumAmount(int premiumAmount) {
		this.premiumAmount = premiumAmount;
	}


	public boolean isCorporatePolicy() {
		return isCorporatePolicy;
	}
	public void setCorporatePolicy(boolean isCorporatePolicy) {
		this.isCorporatePolicy = isCorporatePolicy;
	}

	@Override
	public int calculatePremiumAmount() {
		premiumAmount = (int)(sumInsured*0.30);
		return premiumAmount;
	}

	@Override
	public String toString() {
		return "MediClaimPolicy [policyName=" + policyName + ", preHistory=" + preHistory + ", sumInsured=" + sumInsured
				+ ", premiumAmount=" + premiumAmount + ", isCorporatePolicy=" + isCorporatePolicy + "]";
	}
	
	

	
}//end class
