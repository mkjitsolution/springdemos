package com.mkj.aspect;

import java.time.LocalDateTime;


import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspects {
	
	@Before("execution(public int getMinBalance())")
	public void doLoggingOnReadingBalance()
	{
		System.out.println(" -------->> Logging done @ "+LocalDateTime.now());
	}

	@Before("execution(public int *())")
	public void doLoggingOnReadingInt()
	{
		System.out.println(" -------->> Logging done for int Return @ "+LocalDateTime.now());
	}


	
}



