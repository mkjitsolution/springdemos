package com.mkj.mains;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mkj.beans.Accounts;

public class ConfigurationMain {

	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ConfigurationClass.class);
		Accounts a = context.getBean("accounts",Accounts.class);
		
		System.out.println(a);
		System.out.println("=========================");
		System.out.println(a.getPolicy());
		
		
		
		context.close();
		System.out.println("context closed");
		
	}
}
