package com.mkj.beans.policybeans;

import org.springframework.stereotype.Component;

@Component
public interface Policy {
	
	public int calculatePremiumAmount();
}
