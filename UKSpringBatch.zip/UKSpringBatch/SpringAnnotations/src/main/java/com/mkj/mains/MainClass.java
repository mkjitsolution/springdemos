package com.mkj.mains;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mkj.beans.Accounts;

public class MainClass {

	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring-Annotation-config.xml");
		
		Accounts a = context.getBean("accounts",Accounts.class);
		
		System.out.println(a);
		context.close();
		System.out.println("context closed");
	}
}
